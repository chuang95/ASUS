//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WUSBDevice.rc
//
#define IDI_ICON1                       102
#define IDS_APP_TITLE                   103
#define IDI_ICON3                       104
#define IDI_ICON2                       105
#define IDR_MAINFRAME                   105

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
